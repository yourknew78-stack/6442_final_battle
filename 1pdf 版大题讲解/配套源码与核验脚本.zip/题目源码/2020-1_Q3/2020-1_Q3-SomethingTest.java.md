## SomethingTest.java 原题注释中文对照
已给出 Java 类 Something，其中有一个名为 someMethod 的方法。请使用最少数量的测试用例，使 someMethod 达到完整分支覆盖。

在 SomethingTest.java 的 test() 方法内编写测试。不得改变给定方法的签名，也不得改变给定类的包结构。请将 SomethingTest.java 上传到 Wattle 供评分。

原注释作者：nanwang。
