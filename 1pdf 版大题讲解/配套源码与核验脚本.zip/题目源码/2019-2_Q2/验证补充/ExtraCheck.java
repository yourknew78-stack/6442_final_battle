import tree.BST;
public class ExtraCheck {
 static void check(boolean b) {if(!b) throw new AssertionError();}
 public static void main(String[] args) {
  BST t=new BST();check(!t.find(1));check(t.sumEvenNodes()==0);t.insert(5);t.delete(5);check(!t.find(5));
  for(int n:new int[]{5,3,8,6,9})t.insert(n);check(t.sumEvenNodes()==31);t.delete(5);check(!t.find(5)&&t.find(6)&&t.find(3)&&t.find(8)&&t.find(9));
  t.delete(8);check(t.find(9));t.delete(3);check(!t.find(3));
  System.out.println("PASS: BST empty, root deletion, successor and children counts");
 }
}