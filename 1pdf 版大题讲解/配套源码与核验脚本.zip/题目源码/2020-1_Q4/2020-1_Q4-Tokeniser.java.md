## Tokeniser.java 原题注释中文对照
重要：该类尚未完成，请查找 TODO 注释。

实现 Tokeniser.java 的 next()，将 SQL 命令提取为以下词法单元。

第一个词法单元：originalTokenStr 是 INSERT INTO table_name (column1, column2, column3, ...)；type 为 INSERT_INTO；value 为 table_name (column1, column2, column3, ...)。

第二个词法单元：originalTokenStr 是 VALUES (value1, value2, value3, ...)；type 为 VALUES；value 为 (value1, value2, value3, ...)。

SQL 命令可能缺少括号。如果缺少某些括号，应返回 null。测试见 TokeniserTest.java。

各方法注释：
- next()：返回下一个词法单元，但不改变 buffer；没有更多词法单元或下一个词法单元无效时，返回 null。
- 取出并消费词法单元的方法：返回下一个词法单元，并从 buffer 中移除它；没有更多词法单元或下一个词法单元无效时，返回 null。
- hasNext()：返回 buffer 中是否还有其他词法单元可解析。
