/**
 * IMPORTANT: This class is incomplete. Please look for "TODO" comments.
 * @author huy.pham
 */
public class BST {	
	Node root;

	/**
	 * Node class
	 */
	public class Node {
		String value;
		Node parent;
		Node left;
		Node right;

		public Node(String value) {
			this.value = value;
			this.parent = null;
			this.left = null;
			this.right = null;
		}

		/**
		 * @param s
		 * @return the node that has the given value.
		 */
	    public Node find(String s) {
            int cmp = s.compareTo(value);
            if (cmp == 0) return this;
            Node next = cmp < 0 ? left : right;
            return next == null ? null : next.find(s);
    }

		/**
		 * Insert a new node into the tree
		 * @param s
		 * @return {@link Node}
		 */
		public Node insert(String s) {
            int cmp = s.compareTo(value);
            if (cmp == 0) return this;
            if (cmp < 0) {
                if (left == null) { left = new Node(s); left.parent = this; return left; }
                return left.insert(s);
            }
            if (right == null) { right = new Node(s); right.parent = this; return right; }
            return right.insert(s);
    }
		
		/**
		 * @return pre-order traversal of the nodes that have odd number of children.
		 */
		public String printOddNodes() {
            // 二叉树的奇数个直接孩子只能是 1 个。
            String result = "";
            if ((left == null) != (right == null)) result += value + " ";
            if (left != null) result += left.printOddNodes();
            if (right != null) result += right.printOddNodes();
            return result;
    }
	}

	public String printOddNodes() {
		return root.printOddNodes();
	}
	
	public BST() {
		root = null;
	}

	public Node insert(String value) {
		if (root == null) {
			root = new Node(value);
			return root;
		}

		return root.insert(value);
	}
	
	public Node find(String s) {
		if (root == null) {
			return null;
		}
		
		return root.find(s);
	}
}