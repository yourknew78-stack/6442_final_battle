public class Client {
    private final Operation operation;
    public Client(Operation operation) {
        if (operation == null) throw new IllegalArgumentException("operation required");
        this.operation = operation;
    }
    public int compute() {
        return operation.calculate(); // 通过接口调用选中的运算。
    }
}
