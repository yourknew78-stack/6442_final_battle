public class Subtract implements Operation {

	private final int a;
	private final int b;

	public Subtract(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}

	public int calculate() {
		// 溢出时抛 ArithmeticException，避免静默产生错误整数。
        return Math.subtractExact(a, b);
	}
}
