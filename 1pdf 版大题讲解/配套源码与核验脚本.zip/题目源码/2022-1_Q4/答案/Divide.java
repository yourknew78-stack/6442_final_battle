public class Divide implements Operation {

	private final int a;
	private final int b;

	public Divide(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}

	public int calculate() {
		if (b == 0) throw new ArithmeticException("division by zero");
        if (a == Integer.MIN_VALUE && b == -1) throw new ArithmeticException("integer overflow");
        return a / b; // 本示例明确采用整数除法。
	}
}
