// 统一入口：客户端只依赖接口，不依赖五个具体运算类。
public interface Operation {
    int calculate();
}
