public class ExtraCheck {
 static void check(boolean b) {if(!b) throw new AssertionError();}
 public static void main(String[] args) {
  check(new Client(new Exponentiate(2,3)).compute()==8);check(new Exponentiate(2,0).calculate()==1);
  check(new Add(2,3).calculate()==5);check(new Subtract(2,3).calculate()==-1);check(new Multiply(2,3).calculate()==6);check(new Divide(5,2).calculate()==2);
  try{new Divide(1,0).calculate();throw new AssertionError();}catch(ArithmeticException expected){}
  try{new Exponentiate(2,-1).calculate();throw new AssertionError();}catch(IllegalArgumentException expected){}
  try{new Add(Integer.MAX_VALUE,1).calculate();throw new AssertionError();}catch(ArithmeticException expected){}
  System.out.println("PASS: calculator examples, zero power, integer division and exceptions");
 }
}